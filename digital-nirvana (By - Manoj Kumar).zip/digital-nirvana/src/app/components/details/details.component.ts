import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  imbdID: any;
  movieInformation: [] = [];
  data: any;

  constructor(
    private route: ActivatedRoute,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
    let id = this.route.snapshot.params['id'];
    this.imbdID = id;

    this.authService.getMovieInfo(this.imbdID).subscribe(data => {

      console.log(data);
      if (data.Response == 'True') {
        this.movieInformation.push(data);
      } else {
        alert('Movie does not exist with this IMDB ID');
        this.router.navigate(['/search']);
      }
    });

  }

}
