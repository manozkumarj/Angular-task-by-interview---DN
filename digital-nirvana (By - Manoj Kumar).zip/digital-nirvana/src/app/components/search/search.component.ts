import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service'

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  heading = 'digital-nirvana';
  years: Array<any> = [];
  types: Array<String> = ['Movie', 'Series', 'Episode'];
  title: String;
  type: String;
  year: String;
  moviesList = {
    Response: 'False',
    dataExist: 'no'
  };

  constructor(private authService: AuthService) {
    for (let i = 2000; i <= 2020; i++) {
      this.years.push(i);
    }
    console.log(this.years);
  }


  ngOnInit() {
  }

  onRegisterSubmit() {
    let getTitle = this.title;
    let getType = this.type;
    let getYear = this.year;

    if (getTitle == undefined) {
      alert('Enter title');
      return false;
    }

    if (getType == undefined) {
      alert('Select Type');
      return false;
    }

    if (getYear == undefined) {
      alert('Select Year');
      return false;
    }


    // console.log(getTitle);
    // console.log(getType);
    // console.log(getYear);

    this.authService.getResults(getTitle, getType, getYear).subscribe(data => {

      // console.log(data);
      if (data.Response == 'True') {
        console.log(data);
        this.moviesList = data.Search;
        this.moviesList.dataExist = 'yes';
      } else if (data.Response == 'False') {
        console.log(data.Error);
        this.moviesList.dataExist = 'empty';
        alert(data.Error);
      } else {
        alert('Somethig went wrong...!');
      }
    });

    return false;
  }
}