import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { HttpModule } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthService {
  authToken: any;
  user: any;

  constructor(private http: Http) { }

  getResults(getTitle, getType, getYear) {
    return this.http.get('http://www.omdbapi.com/?apikey=2d2c9886&s=' + getTitle + '&y=' + getYear + '&type=' + getType)
      .map(res => res.json());
  }

  getMovieInfo(getIMDBID) {
    return this.http.get('http://www.omdbapi.com/?apikey=2d2c9886&i=' + getIMDBID)
      .map(res => res.json());
  }

}